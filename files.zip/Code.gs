// LeadScan — Google Apps Script Backend
// Paste this entire file into your Apps Script project

const ADMIN_PASSWORD = 'mycel2025'; // CHANGE THIS before deploying
const SHEET_LEADS = 'Leads';
const SHEET_EVENTS = 'Events';

function doPost(e) {
  const res = ContentService.createTextOutput();
  res.setMimeType(ContentService.MimeType.JSON);
  try {
    const body = JSON.parse(e.postData.contents);
    const action = body.action;
    let result;
    if (action === 'adminLogin')   result = adminLogin(body);
    else if (action === 'saveEvent')    result = saveEvent(body);
    else if (action === 'deleteEvent')  result = deleteEvent(body);
    else if (action === 'getEvents')    result = getEvents(body);
    else if (action === 'validateCode') result = validateCode(body);
    else if (action === 'saveLead')     result = saveLead(body);
    else if (action === 'getLeads')     result = getLeads(body);
    else result = { ok: false, error: 'Unknown action' };
    res.setContent(JSON.stringify(result));
  } catch(err) {
    res.setContent(JSON.stringify({ ok: false, error: err.message }));
  }
  return res;
}

function doGet(e) {
  return doPost({ postData: { contents: JSON.stringify(e.parameter) } });
}

// ── Auth ──────────────────────────────────────────────
function adminLogin(body) {
  if (body.password === ADMIN_PASSWORD) return { ok: true };
  return { ok: false, error: 'Invalid password' };
}

// ── Events ────────────────────────────────────────────
function getEventsSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_EVENTS);
  if (!sh) {
    sh = ss.insertSheet(SHEET_EVENTS);
    sh.appendRow(['code','vendorName','eventName','eventYear','campaignId','crmType','utmSource','utmMedium','utmCampaign','utmContent','apiKey','createdAt']);
    sh.setFrozenRows(1);
  }
  return sh;
}

function getLeadsSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_LEADS);
  if (!sh) {
    sh = ss.insertSheet(SHEET_LEADS);
    sh.appendRow(['id','code','vendorName','eventName','eventYear','campaignId','crmType','firstname','lastname','title','company','email','phone','linkedin','leadtype','sponsored','warm','notes','utmUrl','submittedAt']);
    sh.setFrozenRows(1);
  }
  return sh;
}

function saveEvent(body) {
  if (body.password !== ADMIN_PASSWORD) return { ok: false, error: 'Unauthorized' };
  const sh = getEventsSheet();
  const data = sh.getDataRange().getValues();
  const headers = data[0];
  const codeIdx = headers.indexOf('code');
  // Check for duplicate code
  for (let i = 1; i < data.length; i++) {
    if (data[i][codeIdx] === body.code && (!body.editing || body.editing !== body.code)) {
      return { ok: false, error: 'Event code already exists' };
    }
  }
  // If editing, delete old row
  if (body.editing) {
    for (let i = 1; i < data.length; i++) {
      if (data[i][codeIdx] === body.editing) {
        sh.deleteRow(i + 1);
        break;
      }
    }
  }
  sh.appendRow([
    body.code, body.vendorName, body.eventName, body.eventYear,
    body.campaignId, body.crmType,
    body.utmSource || '', body.utmMedium || 'event',
    body.utmCampaign || '', body.utmContent || '',
    body.apiKey || '',
    new Date().toISOString()
  ]);
  return { ok: true };
}

function deleteEvent(body) {
  if (body.password !== ADMIN_PASSWORD) return { ok: false, error: 'Unauthorized' };
  const sh = getEventsSheet();
  const data = sh.getDataRange().getValues();
  const codeIdx = data[0].indexOf('code');
  for (let i = 1; i < data.length; i++) {
    if (data[i][codeIdx] === body.code) {
      sh.deleteRow(i + 1);
      return { ok: true };
    }
  }
  return { ok: false, error: 'Not found' };
}

function getEvents(body) {
  if (body.password !== ADMIN_PASSWORD) return { ok: false, error: 'Unauthorized' };
  const sh = getEventsSheet();
  const data = sh.getDataRange().getValues();
  if (data.length < 2) return { ok: true, events: [] };
  const headers = data[0];
  const events = data.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
  return { ok: true, events };
}

function validateCode(body) {
  const sh = getEventsSheet();
  const data = sh.getDataRange().getValues();
  if (data.length < 2) return { ok: false, error: 'Invalid code' };
  const headers = data[0];
  const codeIdx = headers.indexOf('code');
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][codeIdx]).toUpperCase() === String(body.code).toUpperCase()) {
      const obj = {};
      headers.forEach((h, j) => obj[h] = data[i][j]);
      // Don't expose admin password or full apiKey
      delete obj.apiKey;
      return { ok: true, event: obj };
    }
  }
  return { ok: false, error: 'Invalid code' };
}

// ── Leads ─────────────────────────────────────────────
function saveLead(body) {
  const sh = getLeadsSheet();
  const utmUrl = buildUTMUrl(body);
  sh.appendRow([
    body.id || Utilities.getUuid(),
    body.code, body.vendorName, body.eventName, body.eventYear,
    body.campaignId, body.crmType,
    body.firstname, body.lastname, body.title, body.company,
    body.email, body.phone, body.linkedin,
    body.leadtype, body.sponsored, body.warm ? 'TRUE' : 'FALSE',
    body.notes, utmUrl,
    new Date().toISOString()
  ]);
  return { ok: true };
}

function getLeads(body) {
  if (body.password !== ADMIN_PASSWORD && !body.code) return { ok: false, error: 'Unauthorized' };
  const sh = getLeadsSheet();
  const data = sh.getDataRange().getValues();
  if (data.length < 2) return { ok: true, leads: [] };
  const headers = data[0];
  let leads = data.slice(1).map(row => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = row[i]);
    return obj;
  });
  // Filter by code for vendor export
  if (body.code && body.password !== ADMIN_PASSWORD) {
    leads = leads.filter(l => String(l.code).toUpperCase() === String(body.code).toUpperCase());
  }
  return { ok: true, leads };
}

function buildUTMUrl(b) {
  if (!b.utmBase) return '';
  try {
    const p = new URLSearchParams || {};
    const parts = [];
    if (b.utmSource) parts.push('utm_source=' + encodeURIComponent(b.utmSource));
    if (b.utmMedium) parts.push('utm_medium=' + encodeURIComponent(b.utmMedium));
    if (b.utmCampaign) parts.push('utm_campaign=' + encodeURIComponent(b.utmCampaign));
    if (b.campaignId) parts.push('utm_id=' + encodeURIComponent(b.campaignId));
    parts.push('utm_term=' + encodeURIComponent(b.leadtype || 'scan'));
    if (b.sponsored === 'yes') parts.push('utm_content=sponsored');
    return b.utmBase + (b.utmBase.includes('?') ? '&' : '?') + parts.join('&');
  } catch(e) { return ''; }
}
